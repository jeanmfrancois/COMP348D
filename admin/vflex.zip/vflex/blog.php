<?php 
/*
Template Name: Blog Template
*/
get_header(); ?>
<div class="eleven columns ">
<div id="content">
    <h2>Blog</h2>
    <hr>
<?php 
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1; 
query_posts("paged=$paged");
while ( have_posts() ) : the_post();

 ?>
		
<article class="post" id="post-<?php the_ID(); ?>">
<div class="title">
<h2><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></h2>
</div>

<div class="postmeta">
	<span class="author">Posted by <?php the_author(); ?> </span> <span class="clock">  <?php the_time('M - j - Y'); ?></span>
</div>

<div class="entry">
<?php
if ( has_post_thumbnail() ) { 
    
    the_post_thumbnail('categorythumb');
    } 
     the_excerpt(); ?>
<div class="clear"></div>
</div>


<div class="singleinfo">
<span class="categori">Categories: <?php the_category(', '); ?> </span>
</div>

</article>
<?php endwhile;
?>

<?php getpagenavi(); 
// Reset Query
wp_reset_query();
?>

</div>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>