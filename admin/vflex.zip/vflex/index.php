<?php get_header(); 
$vibe_option=get_option('vFlex');
?>

<div class="container">
    <?php
                        if(isset($vibe_option['enable_slider'])): ?>
<div class="slidebox">
<div class="flexslider RightWarpShadow RWLarge RWDark">
	<ul class="slides">	
            <?php
            if (!isset($vibe_option['slider_posts']))
                $vibe_option['slider_posts']='';
            
                            
                             $the_query = new WP_Query( array( 'post__in' =>  $vibe_option['slider_posts']) );
                             
                            while ( $the_query->have_posts() ) : $the_query->the_post();
                        if(has_post_thumbnail()){
		?>	
		<li>
			<a href="<?php the_permalink() ?>"><?php the_post_thumbnail('homeslider'); ?></a>
		</li>
		<?php }
                endwhile; 
                wp_reset_postdata(); ?>
	</ul>
</div>
</div>
     <?php
                        endif;
                        ?>
</div>

<div class="container tagline">
    <?php
    echo $vibe_option['tagline'];
    ?>
</div>
<hr>
<div class="container ">
<?php 

if(isset($vibe_option['custom_featured'])){
    echo $vibe_option['custom_featured'];
}
if(!isset($vibe_option['home_cats'])){
    $vibe_option['home_cats']='';
}
$counter=0;
	//$hpostcount = get_option('orio_hpostcount');
	$my_query = new WP_Query('showposts='.$vibe_option['no_of_posts'].'&cat='.$vibe_option['home_cats']);
	while ($my_query->have_posts()) : $my_query->the_post();
?>

<div class="four columns">

<article class="post" id="post-<?php the_ID(); ?>">

<?php
if ( has_post_thumbnail() ) { ?>
	<a href="<?php the_permalink() ?>" >
            <?php the_post_thumbnail('homethumbs');
            ?>
        </a>
<?php } else { ?>
	<a href="<?php the_permalink() ?>"><img class="scale-with-grid" src="<?php bloginfo('template_directory'); ?>/images/dummy.jpg" alt="" /></a>
<?php } ?>

<div class="btitle">
	<h2><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
</div>

<div class="boxentry">
<?php 
the_excerpt();
?>
<div class="clear"></div>
</div>

</article>

</div>

<?php if(++$counter % 4 == 0) : ?>
<div class="clear"></div>
<hr>
<?php endif; ?>
<?php endwhile; ?>
<a href="<?php echo get_page_link($vibe_option['blog']); ?>" class="button right">Read All posts &raquo;</a>
<div class="clear"></div>

</div>
<?php get_footer(); ?>