<?php

define('VIBE_URL',get_stylesheet_directory_uri());


add_action('wp_print_scripts', 'vibe_styles');
function vibe_styles(){
    if (!is_admin()) {  
    wp_register_style( 'base', VIBE_URL .'/stylesheets/base.css' );
    wp_register_style( 'layout', VIBE_URL .'/stylesheets/layout.css' );
    wp_register_style( 'responsive', VIBE_URL .'/stylesheets/responsive-style.css' );
    
    wp_enqueue_style( 'base' );
    wp_enqueue_style('layout' );
    wp_enqueue_style('responsive');
    }
}
add_action('wp_print_scripts', 'vibe_scripts');
function vibe_scripts(){
    if (!is_admin()) {  
wp_enqueue_script('jquery');
wp_enqueue_script('effects', VIBE_URL .'/js/effects.js');
wp_enqueue_script('superfish', VIBE_URL .'/js/superfish.js');
wp_enqueue_script('flexslider', VIBE_URL .'/js/jquery.flexslider-min.js');
wp_enqueue_script('mobilemenu', VIBE_URL .'/js/jquery.mobilemenu.js');
    }
}


/* SIDEBARS */
if ( function_exists('register_sidebar') )

	
	register_sidebar(array(
	'name' => 'Sidebar',
    'before_widget' => '<li class="sidebox %2$s">',
    'after_widget' => '</li>',
	'before_title' => '<div class="sidetitl"><h3>',
    'after_title' => '</h3> </div><hr class="remove-bottom">',
	
    ));
	
	register_sidebar(array(
	'name' => 'Footer',
    'before_widget' => '<div class="four columns"><li class="botwid">',
    'after_widget' => '</li></div>',
	'before_title' => '<h3 class="bothead">',
    'after_title' => '</h3>',
    ));	
	

	
/* CUSTOM MENUS */	

add_action( 'init', 'register_vibe_menus' );
function register_vibe_menus() {
register_nav_menus(
array(
'mainnav' => __( 'Main Menu' )
  )
  );
}

function string_limit_words($string, $word_limit)
{
  $words = explode(' ', $string, ($word_limit + 1));
  if(count($words) > $word_limit)
  array_pop($words);
  return implode(' ', $words);
}

add_filter('the_excerpt', 'vibe_excerpt');
function vibe_excerpt(){
    $vibe_option=get_option('vFlex');
    global $post;
    $excerpt = get_the_excerpt();
  return string_limit_words($excerpt,$vibe_option['excerpt_words']).'<a href="'. get_permalink($post->ID) . '" class="readmore">..read more</a>';
}
/* add read more instead of excerpt */
function new_excerpt_more($more) {
       global $post;
	return '<a href="'. get_permalink($post->ID) . '" class="readmore"> read more</a>';
}
add_filter('excerpt_more', 'new_excerpt_more');


if ( function_exists( 'add_image_size' ) ) { 
	add_image_size( 'homethumbs',230, 230,true ); //300 pixels wide 
	add_image_size( 'homeslider', 960, 350,true);
        add_image_size( 'categorythumb', 300, 180,true);
}

function fallbackmenu(){ ?>
			<div id="mainmenu">
				<ul><li> Go to Adminpanel > Appearance > Menus to create your menu.</li></ul>
			</div>
<?php }	

/*
add_action( 'customize_register', 'themename_customize_register' );

function themename_customize_register($wp_customize) {

$wp_customize->add_section( 'themename_color_scheme', array(
	'title'          => __( 'Color Scheme', 'themename' ),
	'priority'       => 35,
) );

$wp_customize->add_setting( 'themename_theme_options[color_scheme]', array(
	'default'        => 'some-default-value',
	'type'           => 'option',
	'capability'     => 'edit_theme_options',
) );

$wp_customize->add_setting( 'themename_color_scheme', array(
	'default'        => 'some-default-value',
	'type'           => 'option',
	'capability'     => 'edit_theme_options',
) );

$wp_customize->add_setting( 'color_scheme', array(
	'default'        => 'some-default-value',
	'type'           => 'theme_mod',
	'capability'     => 'edit_theme_options',
) );

$wp_customize->add_control( 'themename_color_scheme', array(
	'label'      => __( 'Color Scheme', 'themename' ),
	'section'    => 'themename_color_scheme',
	'settings'   => 'themename_theme_options[color_scheme]',
	'type'       => 'radio',
	'choices'    => array(
		'value1' => 'Choice 1',
		'value2' => 'Choice 2',
		'value3' => 'Choice 3',
		),
) );

$wp_customize->add_control( 'display_header_text', array(
	'settings' => 'header_textcolor',
	'label'    => __( 'Display Header Text' ),
	'section'  => 'header',
	'type'     => 'checkbox',
) );

$wp_customize->add_control( 'display_header_text', array(
	'settings' => 'header_textcolor',
	'label'    => __( 'Display Header Text' ),
	'section'  => 'header',
	'type'     => 'checkbox',
) );

$wp_customize->add_control( 'example_select_box', array(
	'label'   => 'Select Something:',
	'section' => 'nav',
	'type'    => 'select',
	'choices'    => array(
		'value1' => 'Choice 1',
		'value2' => 'Choice 2',
		'value3' => 'Choice 3',
		),
) );

$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'link_color', array(
	'label'   => __( 'Link Color', 'themename' ),
	'section' => 'themename_color_scheme',
	'settings'   => 'themename_theme_options[link_color]',
) ) );

//if ( $wp_customize->is_preview() && ! is_admin() )
//	add_action( 'wp_footer', 'themename_customize_preview', 21);
}

function themename_customize_preview() {
	?>
	<script type="text/javascript">
	( function( $ ){
	wp.customize('setting_name',function( value ) {
		value.bind(function(to) {
			$('.posttitle').css('color', to ? '#' + to : '' );
		});
	});
	} )( jQuery )
	</script>
	<?php 
} 



/* SHORT TITLES */

function short_title($after = '', $length) {
   $mytitle = explode(' ', get_the_title(), $length);
   if (count($mytitle)>=$length) {
       array_pop($mytitle);
       $mytitle = implode(" ",$mytitle). $after;
   } else {
       $mytitle = implode(" ",$mytitle);
   }
       return $mytitle;
}


/* FEATURED THUMBNAILS */

if ( function_exists( 'add_theme_support' ) ) { // Added in 2.9
	add_theme_support( 'post-thumbnails' );


}

/* GET THUMBNAIL URL */

function get_image_url(){
	$image_id = get_post_thumbnail_id();
	$image_url = wp_get_attachment_image_src($image_id,'large');
	$image_url = $image_url[0];
	echo $image_url;
	}	

/* PAGE NAVIGATION */


function getpagenavi(){
?>
<div id="navigation" class="clearfix">
<?php if(function_exists('wp_pagenavi')) : ?>
<?php wp_pagenavi() ?>
<?php else : ?>
        <div class="alignleft"><?php next_posts_link(__('&laquo; Older Entries','Vibe')) ?></div>
        <div class="alignright"><?php previous_posts_link(__('Newer Entries &raquo;','vibe')) ?></div>
        <div class="clear"></div>
<?php endif; ?>

</div>

<?php
}

get_template_part('vibe', 'options');
?>