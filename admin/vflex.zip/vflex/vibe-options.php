<?php
/*
 * 
 * Require the framework class before doing anything else, so we can use the defined urls and dirs
 * Also if running on windows you may have url problems, which can be fixed by defining the framework url first
 *
 */

if(!class_exists('vibe_Options')){
	require_once( dirname( __FILE__ ) . '/options/options.php' );
}

/*
 * 
 * Custom function for filtering the sections array given by theme, good for child themes to override or add to the sections.
 * Simply include this function in the child themes functions.php file.
 *
 * NOTE: the defined constansts for urls, and dir will NOT be available at this point in a child theme, so you must use
 * get_template_directory_uri() if you want to use any of the built in icons
 *
 */
function add_another_section($sections){
	
	//$sections = array();
	$sections[] = array(
				'title' => __('A Section added by hook', 'vibe-opts'),
				'desc' => __('<p class="description">This is a section created by adding a filter to the sections array, great to allow child themes, to add/remove sections from the options.</p>', 'vibe-opts'),
				//all the glyphicons are included in the options folder, so you can hook into them, or link to your own custom ones.
				//You dont have to though, leave it blank for default.
				'icon' => trailingslashit(get_template_directory_uri()).'options/img/glyphicons/glyphicons_062_attach.png',
				//Lets leave this as a blank section, no options just some intro text set above.
				'fields' => array()
				);
	
	return $sections;
	
}//function
//add_filter('vibe-opts-sections-twenty_eleven', 'add_another_section');


/*
 * 
 * Custom function for filtering the args array given by theme, good for child themes to override or add to the args array.
 *
 */
function change_framework_args($args){
	
	$args['dev_mode'] = false;
	
	return $args;
	
}




/*
 * This is the meat of creating the optons page
 *
 * Override some of the default values, uncomment the args and change the values
 * - no $args are required, but there there to be over ridden if needed.
 *
 *
 */

function setup_framework_options(){
$args = array();

//Set it to dev mode to view the class settings/info in the form - default is false
$args['dev_mode'] = false;

//google api key MUST BE DEFINED IF YOU WANT TO USE GOOGLE WEBFONTS
//$args['google_api_key'] = '***';

//Remove the default stylesheet? make sure you enqueue another one all the page will look whack!
//$args['stylesheet_override'] = true;

//Add HTML before the form
$args['intro_text'] = __('<p>Free Responsive Theme, brought to you by VibeThemes.com.</p>', 'vibe-opts');

//Setup custom links in the footer for share icons
$args['share_icons']['twitter'] = array(
										'link' => 'http://twitter.com/vibethemes',
										'title' => 'Folow me on Twitter', 
										'img' => vibe_OPTIONS_URL.'img/glyphicons/glyphicons_322_twitter.png'
										);
$args['share_icons']['facebook'] = array(
										'link' => 'http://facebook.com/vibethemes',
										'title' => 'Get exciting deals on Facebook', 
										'img' => vibe_OPTIONS_URL.'img/glyphicons/glyphicons_320_facebook.png'
										);
//Choose to disable the import/export feature
//$args['show_import_export'] = false;

//Choose a custom option name for your theme options, the default is the theme name in lowercase with spaces replaced by underscores
$args['opt_name'] = 'vFlex';

//Custom menu icon
//$args['menu_icon'] = '';

//Custom menu title for options page - default is "Options"
$args['menu_title'] = __('Vibe Options', 'vibe-opts');

//Custom Page Title for options page - default is "Options"
$args['page_title'] = __('vFlex Theme Options', 'vibe-opts');

//Custom page slug for options page (wp-admin/themes.php?page=***) - default is "vibe_theme_options"
$args['page_slug'] = 'vibe_theme_options';

//Custom page capability - default is set to "manage_options"
//$args['page_cap'] = 'manage_options';

//page type - "menu" (adds a top menu section) or "submenu" (adds a submenu) - default is set to "menu"
//$args['page_type'] = 'submenu';

//parent menu - default is set to "themes.php" (Appearance)
//the list of available parent menus is available here: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
//$args['page_parent'] = 'themes.php';

//custom page location - default 100 - must be unique or will override other items
$args['page_position'] = 27;

//Custom page icon class (used to override the page icon next to heading)
//$args['page_icon'] = 'icon-themes';

//Want to disable the sections showing as a submenu in the admin? uncomment this line
//$args['allow_sub_menu'] = false;
		
//Set ANY custom page help tabs - displayed using the new help tab API, show in order of definition		
$args['help_tabs'][] = array(
							'id' => 'vibe-opts-1',
							'title' => __('Theme Help', 'vibe-opts'),
							'content' => __('<p>Known Issues:<ol><li><a href="">I see a small 20px tab on the top of my theme.</a></li></ol>.</p>', 'vibe-opts')
							);
$args['help_tabs'][] = array(
							'id' => 'vibe-opts-2',
							'title' => __('Theme Support', 'vibe-opts'),
							'content' => __('<p>In case you\'re facing issues with the theme:<ol><li>vFlex Support Forum:<a href="http://www.vibethemes.com/forum/forum/vflex-support" target="_blank">Forum Support</a></li></ol></p>', 'vibe-opts')
							);

//Set the Help Sidebar for the options page - no sidebar by default										
$args['help_sidebar'] = __('<p>For any help/Issues or Feedback, mail us at Vibethemes@gmail.com</p>', 'vibe-opts');



$sections = array();

$sections[] = array(
				'title' => __('Getting Started', 'vibe-opts'),
				'desc' => __('<p class="description">This is a Free Responsive Theme brought to you by VibeThemes.<br /><h3>This themes comes with following features:</h3><ol><li>Responsive theme, supports tab and mobiles</li><li>HomePage slider</li><li>Custom Menus supported</li><li>Blog page template</li><li>Intuitive VibeOptions panel </li><li>Upload Logo/favicon functionality</li><li>Upload/Import/Export functionality</li></ol></h3></p>', 'vibe-opts'),
				//all the glyphicons are included in the options folder, so you can hook into them, or link to your own custom ones.
				//You dont have to though, leave it blank for default.
				'icon' => vibe_OPTIONS_URL.'img/glyphicons/glyphicons_062_attach.png'
				//Lets leave this as a blank section, no options just some intro text set above.
				//'fields' => array()
				);

				
$sections[] = array(
				'icon' => vibe_OPTIONS_URL.'img/glyphicons/glyphicons_061_keynote.png',
				'title' => __('HomePage', 'vibe-opts'),
				'desc' => __('<p class="description">Various HomePage Sections</p>', 'vibe-opts'),
				'fields' => array(
					array(
						'id' => 'tagline', //must be unique
						'type' => 'editor', //builtin fields include:
						//text|textarea|editor|checkbox|multi_checkbox|radio|radio_img|button_set|select|multi_select|color|
                                                //date|divide|info|upload
						'title' => __('Homepage Tag Line', 'vibe-opts'),
						'sub_desc' => __('The main tag line on Home page', 'vibe-opts'),
						'desc' => __('Supports HTML content/Shortcodes.', 'vibe-opts'),
                                                'std' => 'The Awesome Vibe Responsive HTML5 Theme! <button class="cupid-blue big right">Download Now</button><button class="cupid-green big right">See Demo</button>
  '
						//'validate' => '', //builtin validation includes: email|html|html_custom|no_html|js|numeric|url
						//'msg' => 'custom error message', //override the default validation error message for specific fields
						//'std' => '', //This is a default value, used to set the options on theme activation, and if the user hits the Reset to defaults Button
						//'class' => '' //Set custom classes for elements if you want to do something a little different - default is "regular-text"
						),
    
                                    array(
						'id' => 'custom_featured_enable',
						'type' => 'checkbox_hide_below',
						'title' => __('Enable Custom Featured Section', 'vibe-opts'), 
						'sub_desc' => __('Overrides Features selection.', 'vibe-opts'),
						'desc' => __('Custom features, HTML/CSS/JS accepted, overrides features.', 'vibe-opts'),
						),
                                    array(
						'id' => 'custom_featured',
						'type' => 'editor',
						'title' => __('Custom Featured Section', 'vibe-opts'), 
						'sub_desc' => __('Custom Features section', 'vibe-opts'),
						'desc' => __('Enter HTML/CSS/JS validated.HomePage featured overridden.', 'vibe-opts'),
						'std' => ''
						),  
                                     array(
						'id' => 'excerpt_words',
						'type' => 'text',
						'title' => __('Featured Excerpts words', 'vibe-opts'),
						'sub_desc' => __('HomePage featured para.', 'vibe-opts'),
						'desc' => __('Enter Number of Words fr Featured para..', 'vibe-opts'),
						'validate' => 'numeric',
						'std' => '20',
                                                'default' => '20'
						),
                                    array(
						'id' => 'blog_enable',
						'type' => 'checkbox_hide_below',
						'title' => __('Show blog posts on HomePage', 'vibe-opts'), 
						'sub_desc' => __('Enables Blog', 'vibe-opts'),
						'desc' => __('Show posts on homepage.', 'vibe-opts'),
                                                'std' =>1,
                                                'default'=>1
						),
                                 
                                    array(
						'id' => 'home_cats',
						'type' => 'cats_multi_select',
						'title' => __('HomePage Blog section', 'vibe-opts'), 
						'sub_desc' => __('Selects recent posts from these categories', 'vibe-opts'),
						'desc' => __('Default all selected.', 'vibe-opts'),
						'args' => array('number' => '10')//uses get_categories
                                                ),
                                    
                                    array(
						'id' => 'no_of_posts',
						'type' => 'text',
						'title' => __('No of posts shown on Homepage', 'vibe-opts'), 
						'sub_desc' => __('Multiple of 4', 'vibe-opts'),
						'desc' => __('Select multiple of 4 for proper indentation.', 'vibe-opts'),
						'std' => 8,
                                                'default'=>8,
                                                'validate' => 'numeric'
						)
				    
					
					)
				);
$sections[] = array(
				'icon' => vibe_OPTIONS_URL.'img/glyphicons/glyphicons_157_show_lines.png',
				'title' => __('Slider Settings', 'vibe-opts'),
				'desc' => __('<p class="description">HomePage Slider settings</p>', 'vibe-opts'),
				'fields' => array(
                                          array(
						'id' => 'enable_slider',
						'type' => 'checkbox',
						'title' => __('Enable Slider', 'vibe-opts'), 
						'sub_desc' => __('Enable Flex slider on HomePage', 'vibe-opts'),
						'desc' => __('Enable slider.', 'vibe-opts'),
						'std' => '1'// 1 = on | 0 = off
						),
                                       
                                 
                                         array(
						'id' => 'slider_posts',
						'type' => 'posts_multi_select',
						'title' => __('HomePage Slider posts', 'vibe-opts'), 
						'sub_desc' => __('Select slider posts', 'vibe-opts'),
						'desc' => __('Selects featured images, from selected posts.', 'vibe-opts'),
						'args' => array('number' => '10')//uses get_categories
                                                ),
                                    
													
					)
				);


$sections[] = array(
				'icon' => vibe_OPTIONS_URL.'img/glyphicons/glyphicons_023_cogwheels.png',
				'title' => __('Settings', 'vibe-opts'),
				'desc' => __('<p class="description">Theme Settings</p>', 'vibe-opts'),
				'fields' => array(
                                     
					array(
						'id' => 'logo',
						'type' => 'upload',
						'title' => __('Upload Logo', 'vibe-opts'), 
						'sub_desc' => __('Upload a high quality logo', 'vibe-opts'),
						'desc' => __('Current Logo dimension: 70px x 73px.', 'vibe-opts'),
                                                'std' => VIBE_URL.'/images/logo.png'
						),
					array(
						'id' => 'favicon',
						'type' => 'upload',
						'title' => __('Upload Favicon', 'vibe-opts'), 
						'sub_desc' => __('Upload a favicon', 'vibe-opts'),
						'desc' => __('Favicon size: 16px X 16 px.', 'vibe-opts'),
                                                'std' => VIBE_URL.'/images/favicon.png'
						),
                                    array(
						'id' => 'blog',
						'type' => 'pages_select',
						'title' => __('Select Blog page', 'vibe-opts'), 
						'sub_desc' => __('Page associated with template Blog', 'vibe-opts'),
						'desc' => __('Latest Blog posts shown', 'vibe-opts'),
                                                'std' => ''
						),
                                    
                                    array(
						'id' => 'theme',
						'type' => 'radio_img',
						'title' => __('Available Theme Styles', 'vibe-opts'), 
						'sub_desc' => __('Select a theme style', 'vibe-opts'),
						'desc' => __('Theme style.', 'vibe-opts'),
						'options' => array(
                                                    '1' => array('title' => 'Light', 'img' => 'images/align-none.png')
										//'2' => array('title' => 'Light', 'img' => 'images/align-left.png')
											),//Must provide key => value(array:title|img) pairs for radio options
						'std' => '2'
						),
                                    array(
						'id' => 'facebook',
						'type' => 'text',
						'title' => __('Facebook Page', 'vibe-opts'), 
						'sub_desc' => __('Your facebook fanpage url', 'vibe-opts'),
						'desc' => __('Include complete url', 'vibe-opts'),
						'std' => 'http://www.facebook.com/vibethemes',
                                                'default'=>'http://www.facebook.com/vibethemes',
                                                'validate' => 'url'
						),
                                    array(
						'id' => 'twitter',
						'type' => 'text',
						'title' => __('Twitter User Url', 'vibe-opts'), 
						'sub_desc' => __('Your twitter profile url', 'vibe-opts'),
						'desc' => __('Include complete url', 'vibe-opts'),
						'std' => 'http://www.twitter.com/vibethemes',
                                                'default'=>'http://www.twitter.com/vibethemes',
                                                'validate' => 'url'
						),
                                    array(
						'id' => 'google',
						'type' => 'text',
						'title' => __('Google page Url', 'vibe-opts'), 
						'sub_desc' => __('Your Google plus page url', 'vibe-opts'),
						'desc' => __('Include complete url', 'vibe-opts'),
						'std' => 'https://plus.google.com/b/107421230631579548079/',
                                                'default'=>'https://plus.google.com/b/107421230631579548079/',
                                                'validate' => 'url'
						),
                                    array(
						'id' => 'footer_text',
						'type' => 'editor',
						'title' => __('Custom footer copyright text', 'vibe-opts'), 
						'sub_desc' => __('Custom footer.', 'vibe-opts'),
						'desc' => __('Enter HTML/CSS/JS validated.HomePage featured overridden.', 'vibe-opts'),
						'std' => '&copy;<a href="http://www.vibethemes.com">VibeThemes</a> 2012, Personal Use license,'
						),  
			        									
					)
				);


				
				
	$tabs = array();
			
	if (function_exists('wp_get_theme')){
		$theme_data = wp_get_theme();
		$theme_uri = $theme_data->get('ThemeURI');
		$description = $theme_data->get('Description');
		$author = $theme_data->get('Author');
		$version = $theme_data->get('Version');
		$tags = $theme_data->get('Tags');
	}else{
		$theme_data = get_theme_data(trailingslashit(get_stylesheet_directory()).'style.css');
		$theme_uri = $theme_data['URI'];
		$description = $theme_data['Description'];
		$author = $theme_data['Author'];
		$version = $theme_data['Version'];
		$tags = $theme_data['Tags'];
	}	

	$theme_info = '<div class="vibe-opts-section-desc">';
	$theme_info .= '<p class="vibe-opts-theme-data description theme-uri">'.__('<strong>Theme URL:</strong> ', 'vibe-opts').'<a href="'.$theme_uri.'" target="_blank">'.$theme_uri.'</a></p>';
	$theme_info .= '<p class="vibe-opts-theme-data description theme-author">'.__('<strong>Author:</strong> ', 'vibe-opts').$author.'</p>';
	$theme_info .= '<p class="vibe-opts-theme-data description theme-version">'.__('<strong>Version:</strong> ', 'vibe-opts').$version.'</p>';
	$theme_info .= '<p class="vibe-opts-theme-data description theme-description">'.$description.'</p>';
	$theme_info .= '<p class="vibe-opts-theme-data description theme-tags">'.__('<strong>Tags:</strong> ', 'vibe-opts').implode(', ', $tags).'</p>';
	$theme_info .= '</div>';


        $donate_info = '<div class="vibe-opts-section-desc">';
         $donate_info .= 'Donate some:<br/>
         <a href="https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=99fusion%40gmail.com&item_name=vFlex Free Theme Donation&no_note=1&tax=0&amount=19&currency_code=USD" target="_blank">$19 USD</a> |
        <a href="https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=99fusion%40gmail.com&item_name=vFlex Free Theme Donation&no_note=1&tax=0&amount=9&currency_code=USD" target="_blank">$9 USD</a> |
        <a href="https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=99fusion%40gmail.com&item_name=vFlex Free Theme Donation&no_note=1&tax=0&amount=6&currency_code=USD" target="_blank">$6 USD</a> |
        <a href="https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=99fusion%40gmail.com&item_name=vFlex Free Theme Donation&no_note=1&tax=0&amount=3&currency_code=USD" target="_blank">$3 USD</a>
        ';
          $donate_info .= '<br /><br />Follow us at <br/>
 <p>             
<a href="https://twitter.com/vibethemes" class="twitter-follow-button" data-show-count="false" data-size="large" data-dnt="true">Follow @vibethemes</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
    </p><p>          
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, "script", "facebook-jssdk"));</script>
    <div class="fb-like" data-href="http://www.vibethemes.com" data-send="true" data-width="450" data-show-faces="true"></div>
</p>
<p>
<a href="http://feeds.feedburner.com/VibeThemes" title="Subscribe to my feed" rel="alternate" type="application/rss+xml"><img src="http://www.feedburner.com/fb/images/pub/feed-icon32x32.png" alt="" style="border:0"/></a><a href="http://feeds.feedburner.com/VibeThemes" title="Subscribe to my feed" rel="alternate" type="application/rss+xml">Subscribe @ VibeThemes</a>
</p></div>';
          
        
	$tabs['theme_info'] = array(
					'icon' => vibe_OPTIONS_URL.'img/glyphicons/glyphicons_195_circle_info.png',
					'title' => __('Theme Information', 'vibe-opts'),
					'content' => $theme_info
					);
        
        $tabs['theme_donate'] = array(
					'icon' => vibe_OPTIONS_URL.'img/glyphicons/glyphicons_195_circle_info.png',
					'title' => __('Promote Us', 'vibe-opts'),
					'content' => $donate_info
					);
	
	if(file_exists(trailingslashit(get_stylesheet_directory()).'README.html')){
		$tabs['theme_docs'] = array(
						'icon' => vibe_OPTIONS_URL.'img/glyphicons/glyphicons_071_book.png',
						'title' => __('Documentation', 'vibe-opts'),
						'content' => nl2br(file_get_contents(trailingslashit(get_stylesheet_directory()).'README.html'))
						);
	}//if

	global $vibe_Options;
	$vibe_Options = new vibe_Options($sections, $args, $tabs);

}//function
add_action('init', 'setup_framework_options', 0);

/*
 * 
 * Custom function for the callback referenced above
 *
 */
function my_custom_field($field, $value){
	print_r($field);
	print_r($value);

}//function

/*
 * 
 * Custom function for the callback validation referenced above
 *
 */
function validate_callback_function($field, $value, $existing_value){
	
	$error = false;
	$value =  'just testing';
	/*
	do your validation
	
	if(something){
		$value = $value;
	}elseif(somthing else){
		$error = true;
		$value = $existing_value;
		$field['msg'] = 'your custom error message';
	}
	*/
	
	$return['value'] = $value;
	if($error == true){
		$return['error'] = $field;
	}
	return $return;
	
}//function
?>