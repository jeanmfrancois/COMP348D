<div class="clear"></div>
</div>

<div class="footcover">
<div class="container">
<?php include (TEMPLATEPATH . '/bottom.php'); ?>
<div id="footer">

	<div class="fcred">
	  some copyrighted text	
        </div>	
	<div class='clear'></div>	
<?php wp_footer(); ?>

</div></div>


</div>
</body>
</html>      